try:
    from cs231n.classifiers.k_nearest_neighbor import *
    from cs231n.classifiers.linear_classifier import *
except:
    
    from classifiers.k_nearest_neighbor import *
    from classifiers.linear_classifier import *
    